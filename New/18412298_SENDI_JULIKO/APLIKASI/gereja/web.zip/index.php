<?php 
	HEADER("LOCATION:backend/index.php");
?>